// ---------------------------------------------------------------------------
// Pure gesture math for the editor canvas.
//
// Nothing in this file touches the DOM, React, or Zustand. It only takes
// plain numbers in and returns plain numbers out. That is deliberate:
//
//   1. It's unit-testable without a browser (see gestureMath.test.ts, run
//      with `npx tsx scripts/gestureMath.test.ts`).
//   2. It's the part of the interaction system a future React Native
//      gesture handler can reuse as-is — only the pointer-event plumbing
//      around it differs between web and native.
//
// EditorCanvas.tsx is responsible for turning pointer events into the
// inputs below, applying the outputs to transient (non-committed) render
// state during the gesture, and committing a single patch to the store
// when the gesture ends.
// ---------------------------------------------------------------------------

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Point {
  x: number;
  y: number;
}

// ---- rotation ---------------------------------------------------------

/**
 * Snaps an angle (in degrees) to the nearest multiple of `increment` when
 * it's within `threshold` degrees of it. Using a 15° increment covers the
 * 15/45/90/180 marks the spec calls out, since they're all multiples of 15.
 */
export function snapAngle(deg: number, increment = 15, threshold = 4): number {
  const nearest = Math.round(deg / increment) * increment;
  return Math.abs(deg - nearest) < threshold ? nearest : Math.round(deg);
}

export function computeRotateTarget(params: {
  centerClientX: number;
  centerClientY: number;
  startAngleClient: number; // atan2 at gesture start, degrees
  startRotation: number; // element rotation at gesture start
  nowClientX: number;
  nowClientY: number;
}): number {
  const now =
    (Math.atan2(params.nowClientY - params.centerClientY, params.nowClientX - params.centerClientX) * 180) /
    Math.PI;
  const raw = params.startRotation + (now - params.startAngleClient);
  return snapAngle(raw);
}

// ---- move + snapping ---------------------------------------------------

export interface SnapCandidates {
  /** x positions worth snapping the moving box's left/centerX/right edge to */
  xs: number[];
  /** y positions worth snapping the moving box's top/centerY/bottom edge to */
  ys: number[];
}

/** Canvas-center, margin, and other-element edge/center candidates. */
export function buildSnapCandidates(
  canvasWidth: number,
  canvasHeight: number,
  others: Rect[],
  marginRatio = 0.06
): SnapCandidates {
  const margin = Math.round(canvasWidth * marginRatio);
  const marginY = Math.round(canvasHeight * marginRatio);
  const xs = [canvasWidth / 2, margin, canvasWidth - margin];
  const ys = [canvasHeight / 2, marginY, canvasHeight - marginY];
  for (const o of others) {
    xs.push(o.x, o.x + o.width, o.x + o.width / 2);
    ys.push(o.y, o.y + o.height, o.y + o.height / 2);
  }
  return { xs, ys };
}

function bestSnap(
  edges: { value: number; offset: number }[],
  candidates: number[],
  threshold: number
): { snapped: number; guide: number } | null {
  let best: { snapped: number; guide: number; dist: number } | null = null;
  for (const edge of edges) {
    for (const c of candidates) {
      const d = Math.abs(edge.value - c);
      if (d < threshold && (!best || d < best.dist)) {
        best = { snapped: c - edge.offset, guide: c, dist: d };
      }
    }
  }
  return best ? { snapped: best.snapped, guide: best.guide } : null;
}

export function computeMoveSnap(
  raw: Rect,
  candidates: SnapCandidates,
  threshold = 14
): { x: number; y: number; guideX?: number; guideY?: number } {
  const xEdges = [
    { value: raw.x, offset: 0 },
    { value: raw.x + raw.width / 2, offset: raw.width / 2 },
    { value: raw.x + raw.width, offset: raw.width },
  ];
  const yEdges = [
    { value: raw.y, offset: 0 },
    { value: raw.y + raw.height / 2, offset: raw.height / 2 },
    { value: raw.y + raw.height, offset: raw.height },
  ];

  const xSnap = bestSnap(xEdges, candidates.xs, threshold);
  const ySnap = bestSnap(yEdges, candidates.ys, threshold);

  return {
    x: xSnap ? xSnap.snapped : raw.x,
    y: ySnap ? ySnap.snapped : raw.y,
    guideX: xSnap?.guide,
    guideY: ySnap?.guide,
  };
}

// ---- resize -------------------------------------------------------------

export function computeResizeTarget(params: {
  handle: string; // 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw'
  base: Rect;
  dx: number;
  dy: number;
  minSize?: number;
  lockAspect?: boolean;
  ratio?: number; // base.width / base.height, required if lockAspect
}): Rect {
  const { handle, base, dx, dy, lockAspect, ratio } = params;
  const minSize = params.minSize ?? 16;
  let { x, y, width: w, height: h } = base;

  if (handle.includes('e')) w = Math.max(minSize, base.width + dx);
  if (handle.includes('w')) {
    w = Math.max(minSize, base.width - dx);
    x = base.x + base.width - w;
  }
  if (handle.includes('s')) h = Math.max(minSize, base.height + dy);
  if (handle.includes('n')) {
    h = Math.max(minSize, base.height - dy);
    y = base.y + base.height - h;
  }

  if (lockAspect && ratio) {
    if (handle === 'e' || handle === 'w') {
      h = Math.max(minSize, Math.round(w / ratio));
      y = base.y + (base.height - h) / 2;
    } else if (handle === 'n' || handle === 's') {
      w = Math.max(minSize, Math.round(h * ratio));
      x = base.x + (base.width - w) / 2;
    } else {
      h = Math.max(minSize, Math.round(w / ratio));
      if (handle.includes('n')) y = base.y + base.height - h;
    }
  }

  return { x, y, width: w, height: h };
}

// ---- pinch zoom (focal-point preserving) --------------------------------

export interface PinchZoomInput {
  startDistance: number;
  startZoom: number;
  startPan: Point;
  /** two-finger midpoint at gesture start, in client px */
  startMidpoint: Point;
  /** the wrap element's own center, in client px (rect.left + width/2, ...) */
  wrapCenter: Point;
  minZoom: number;
  maxZoom: number;
}

/**
 * Solves for the pan that keeps the same canvas-space point under the
 * fingers as zoom changes, instead of always zooming around the stage's own
 * center. `currentMidpoint` may have drifted from `startMidpoint` (the
 * fingers moved as well as spread), which this also accounts for.
 */
export function computePinchZoomPan(
  input: PinchZoomInput,
  currentDistance: number,
  currentMidpoint: Point
): { zoom: number; pan: Point } {
  const rawZoom = input.startZoom * (currentDistance / Math.max(1, input.startDistance));
  const zoom = Math.max(input.minZoom, Math.min(input.maxZoom, rawZoom));

  // Constant (for this gesture) canvas-space offset from the stage's own
  // center that sat under the fingers when the gesture began. Dividing by
  // startZoom alone (not startZoom*fitScale) is intentional: fitScale is a
  // fixed multiplier that cancels out between this line and the one below,
  // so the function doesn't need to know it.
  const stageOffsetX = (input.startMidpoint.x - input.wrapCenter.x - input.startPan.x) / input.startZoom;
  const stageOffsetY = (input.startMidpoint.y - input.wrapCenter.y - input.startPan.y) / input.startZoom;

  return {
    zoom,
    pan: {
      x: currentMidpoint.x - input.wrapCenter.x - stageOffsetX * zoom,
      y: currentMidpoint.y - input.wrapCenter.y - stageOffsetY * zoom,
    },
  };
}
