import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Edit3, Crop, Check, RotateCw, Move, MoreHorizontal } from 'lucide-react';
import { DesignElement, Project, TextElement } from '../types';
import { useStore } from '../store/useStore';
import { BackgroundView, ElementView } from '../render/Render';
import { IcCopy, IcSwap, IcTrash, IcUp } from '../ui/icons';
import { measureTextBox } from '../utils/measureText';
import {
  buildSnapCandidates,
  computeMoveSnap,
  computePinchZoomPan,
  computeResizeTarget,
  computeRotateTarget,
  type SnapCandidates,
} from './gestureMath';

import { renderToJpeg } from '../utils/exporter';

/**
 * Live, uncommitted edits for whichever element(s) are mid-gesture, keyed by
 * element id. Kept out of the Zustand store on purpose — see the note above
 * gestureMath.ts. The store only hears about the change once, when the
 * gesture ends (onPointerUp), as a single updateMany patch.
 */
type Transient = Record<string, Partial<Pick<DesignElement, 'x' | 'y' | 'width' | 'height' | 'rotation'>>>;

const MIN_Z = 0.4;
const MAX_Z = 4;
const SNAP = 14; // canvas px tolerance for centre/edge guides

type Gesture =
  | { kind: 'none' }
  | {
      kind: 'move';
      id: string;
      sx: number;
      sy: number;
      ox: number;
      oy: number;
      siblings: { id: string; ox: number; oy: number }[];
      candidates: SnapCandidates;
      /** True only when this drag started on an already-selected text layer's
       *  body — the signal to enter text edit if the pointer never moves. */
      wasAlreadySelected: boolean;
    }
  | { kind: 'resize'; id: string; handle: string; sx: number; sy: number; b: { x: number; y: number; w: number; h: number }; ratio: number }
  | { kind: 'rotate'; id: string; cx: number; cy: number; start: number; from: number }
  | { kind: 'pan'; sx: number; sy: number; ox: number; oy: number }
  | {
      kind: 'pinch';
      d0: number;
      z0: number;
      /** two-finger midpoint at gesture start, client px */
      mx: number;
      my: number;
      ox: number;
      oy: number;
      /** wrap element's own center, client px — fixed for the gesture */
      wrapCenterX: number;
      wrapCenterY: number;
    };

export interface CanvasHandle {
  zoomBy: (f: number) => void;
  fit: () => void;
  zoom: number;
  focusOn: (id: string) => void;
  startEditText: (id: string) => void;
  commitEdit: () => void;
  getThumbnail: () => Promise<string | null>;
}

interface Props {
  project: Project;
  onRequestImage: (id: string) => void;
  onCropImage?: (id: string) => void;
  onEditingChange?: (editing: boolean) => void;
  handleRef?: React.MutableRefObject<CanvasHandle | null>;
}

export function EditorCanvas({
  project,
  onRequestImage,
  onCropImage,
  onEditingChange,
  handleRef,
}: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const selectedId = useStore((s) => s.selectedId);
  const select = useStore((s) => s.select);
  const update = useStore((s) => s.update);
  const updateMany = useStore((s) => s.updateMany);
  const snapshot = useStore((s) => s.snapshot);
  const del = useStore((s) => s.del);
  const duplicate = useStore((s) => s.duplicate);
  const reorder = useStore((s) => s.reorder);

  const pendingMove = useRef<{ clientX: number; clientY: number } | null>(null);
  const rafId = useRef<number | null>(null);

  const [fitScale, setFitScale] = useState(0.3);
  const [zoom, setZoom] = useState(1); // multiplier on top of fitScale
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [guides, setGuides] = useState<{ x?: number; y?: number }>({});

  const gesture = useRef<Gesture>({ kind: 'none' });
  const pointers = useRef<Map<number, { x: number; y: number }>>(new Map());
  const moved = useRef(false);

  // Live uncommitted transform for the element(s) currently mid-gesture.
  // Null when nothing is being dragged/resized/rotated. Mirrored into a ref
  // (transientRef) because onPointerUp needs the *just-computed* value
  // synchronously to commit it — reading the state variable there would see
  // last render's value, since setState doesn't apply until the next render.
  const [transient, setTransient] = useState<Transient | null>(null);
  const transientRef = useRef<Transient | null>(null);
  const applyTransient = useCallback((patch: Transient | null) => {
    transientRef.current = patch;
    setTransient(patch);
  }, []);
  // Guards against taking more than one undo snapshot per gesture — we take
  // it lazily, on the first real write, so a tap that never moves doesn't
  // push a no-op entry onto the history stack.
  const historySaved = useRef(false);

  const scale = fitScale * zoom;
  const els = useMemo(() => [...project.elements].sort((a, b) => a.z - b.z), [project.elements]);
  const selected = project.elements.find((e) => e.id === selectedId) || null;
  // Selection chrome must track the live (uncommitted) transform during a
  // gesture, or the handles visibly lag a frame behind the shape they're
  // supposed to surround.
  const displaySelected = selected && transient?.[selected.id] ? { ...selected, ...transient[selected.id] } : selected;

  // ---- fit to screen -------------------------------------------------------
  const computeFit = useCallback(() => {
    const w = wrapRef.current;
    if (!w) return;
    const pad = 28;
    const s = Math.min((w.clientWidth - pad) / project.canvas.width, (w.clientHeight - pad) / project.canvas.height);
    setFitScale(s);
  }, [project.canvas]);

  useEffect(() => {
    computeFit();
    const ro = new ResizeObserver(computeFit);
    if (wrapRef.current) ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, [computeFit]);

  const clampPan = useCallback((p: { x: number; y: number }, z: number) => {
    const w = wrapRef.current;
    if (!w) return p;
    const dispW = project.canvas.width * fitScale * z;
    const dispH = project.canvas.height * fitScale * z;
    const maxX = Math.max(0, (dispW - w.clientWidth) / 2 + 40);
    const maxY = Math.max(0, (dispH - w.clientHeight) / 2 + 40);
    return { x: Math.max(-maxX, Math.min(maxX, p.x)), y: Math.max(-maxY, Math.min(maxY, p.y)) };
  }, [project.canvas, fitScale]);

  const applyZoom = useCallback((next: number, p = pan) => {
    const z = Math.max(MIN_Z, Math.min(MAX_Z, next));
    setZoom(z);
    setPan(clampPan(p, z));
  }, [clampPan, pan]);

  // ---- inline text editing methods -----------------------------------------
  const startEdit = useCallback((id: string) => {
    const el = project.elements.find((x) => x.id === id);
    if (!el || el.type !== 'text') return;
    snapshot();
    setEditText((el as TextElement).text);
    setEditingId(id);
    // Re-fit the box height to the current text at the current width before
    // showing the editor, so edit mode never opens on a stale/oversized box
    // (that stale extra height is what read as a blank phantom second line).
    const t = el as TextElement;
    const fit = measureTextBox(t, { maxWidth: t.width });
    if (Math.abs(fit.height - t.height) > 1) {
      update(id, { height: fit.height } as any);
    }
  }, [project.elements, snapshot, update]);

  const commitEdit = useCallback(() => {
    if (editingId && textareaRef.current) {
      const el = project.elements.find((e) => e.id === editingId) as TextElement;
      // Preserve explicit newlines and line breaks created during editing
      const cleanText = editText.replace(/\r\n/g, '\n').trimEnd();
      if (el && cleanText) {
        // Measure with maxWidth constrained to the text box's current width so wrapped lines and newlines are preserved
        const fit = measureTextBox({ ...el, text: cleanText }, { maxWidth: el.width });
        update(editingId, { text: cleanText, width: el.width, height: Math.max(fit.height, 20), autoFit: false } as any);
      } else if (el && !cleanText) {
        // If empty, reset
        update(editingId, { text: 'Text', autoFit: false } as any);
      }
    }
    setEditingId(null);
  }, [editingId, editText, update, project]);

  useEffect(() => {
    if (editingId && textareaRef.current) {
      const ta = textareaRef.current;
      ta.focus();
      // Place the caret at the end (Canva-style) rather than selecting
      // everything — lets you just backspace and keep typing.
      const len = ta.value.length;
      ta.setSelectionRange(len, len);
    }
  }, [editingId]);

  useEffect(() => {
    if (!handleRef) return;
    handleRef.current = {
      zoom,
      zoomBy: (f) => applyZoom(zoom * f),
      fit: () => { setZoom(1); setPan({ x: 0, y: 0 }); },
      focusOn: (id) => {
        const el = project.elements.find((e) => e.id === id);
        const w = wrapRef.current;
        if (!el || !w) return;
        const target = Math.max(1, Math.min(3, (w.clientWidth * 0.55) / (el.width * fitScale)));
        const cx = el.x + el.width / 2 - project.canvas.width / 2;
        const cy = el.y + el.height / 2 - project.canvas.height / 2;
        setZoom(target);
        setPan(clampPan({ x: -cx * fitScale * target, y: -cy * fitScale * target }, target));
        select(id);
      },
      startEditText: (id) => startEdit(id),
      commitEdit: () => commitEdit(),
      getThumbnail: async () => {
        if (!stageRef.current) return null;
        // Temporarily clear scaling for the export
        const node = stageRef.current.firstElementChild as HTMLElement;
        if (!node) return null;
        const oldTransform = node.style.transform;
        node.style.transform = 'scale(1)';
        try {
          const url = await renderToJpeg(node, project.canvas.width, project.canvas.height);
          return url;
        } finally {
          node.style.transform = oldTransform;
        }
      },
    };
  }, [handleRef, zoom, applyZoom, project.elements, fitScale, clampPan, select, project.canvas, startEdit, commitEdit]);

  useEffect(() => { onEditingChange?.(!!editingId); }, [editingId, onEditingChange]);

  // ---- gestures ------------------------------------------------------------
  const onPointerDown = (e: React.PointerEvent) => {
    const target = e.target as Element;
    if (target.tagName && target.tagName.toLowerCase() === 'textarea') return;

    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    moved.current = false;

    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      const wrapRect = wrapRef.current?.getBoundingClientRect();
      gesture.current = {
        kind: 'pinch',
        d0: Math.hypot(a.x - b.x, a.y - b.y),
        z0: zoom,
        mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2,
        ox: pan.x, oy: pan.y,
        wrapCenterX: wrapRect ? wrapRect.left + wrapRect.width / 2 : (a.x + b.x) / 2,
        wrapCenterY: wrapRect ? wrapRect.top + wrapRect.height / 2 : (a.y + b.y) / 2,
      };
      return;
    }

    // Use closest() rather than reading target.dataset directly — the move
    // and rotate knobs contain an icon, so a tap that lands on the icon
    // itself (not the bare div) was missing the handle and falling through
    // to "tapped empty space", which deselected the layer.
    const handle = target.closest('[data-handle]')?.getAttribute('data-handle') || undefined;
    if (handle && selected) {
      e.stopPropagation();
      historySaved.current = false; // taken lazily on first real write
      if (handle === 'rotate') {
        const r = (document.getElementById(`el-${selected.id}`) as HTMLElement).getBoundingClientRect();
        const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
        gesture.current = {
          kind: 'rotate', id: selected.id, cx, cy,
          start: (Math.atan2(e.clientY - cy, e.clientX - cx) * 180) / Math.PI,
          from: selected.rotation,
        };
      } else if (handle === 'move') {
        const siblings = selected.groupId
          ? project.elements.filter((x) => x.groupId === selected.groupId && x.id !== selected.id).map((x) => ({ id: x.id, ox: x.x, oy: x.y }))
          : [];
        const others = project.elements.filter(
          (x) => !x.hidden && x.id !== selected.id && !(selected.groupId && x.groupId === selected.groupId)
        );
        gesture.current = {
          kind: 'move', id: selected.id, sx: e.clientX, sy: e.clientY, ox: selected.x, oy: selected.y, siblings,
          candidates: buildSnapCandidates(project.canvas.width, project.canvas.height, others),
          wasAlreadySelected: false, // this is the dedicated move knob, not a tap on the body
        };
      } else {
        gesture.current = {
          kind: 'resize', id: selected.id, handle,
          sx: e.clientX, sy: e.clientY,
          b: { x: selected.x, y: selected.y, w: selected.width, h: selected.height },
          ratio: selected.width / Math.max(1, selected.height),
        };
      }
      (e.currentTarget as Element).setPointerCapture(e.pointerId);
      return;
    }

    const hitId = target.closest('[data-el]')?.getAttribute('data-el') || null;
    if (hitId) {
      const el = project.elements.find((x) => x.id === hitId);
      if (editingId && editingId !== hitId) commitEdit();
      const wasAlreadySelected = hitId === selectedId;
      select(hitId);
      if (el && !el.locked && editingId !== hitId) {
        historySaved.current = false;
        const siblings = el.groupId
          ? project.elements.filter((x) => x.groupId === el.groupId && x.id !== el.id).map((x) => ({ id: x.id, ox: x.x, oy: x.y }))
          : [];
        const others = project.elements.filter(
          (x) => !x.hidden && x.id !== el.id && !(el.groupId && x.groupId === el.groupId)
        );
        gesture.current = {
          kind: 'move', id: hitId, sx: e.clientX, sy: e.clientY, ox: el.x, oy: el.y, siblings,
          candidates: buildSnapCandidates(project.canvas.width, project.canvas.height, others),
          wasAlreadySelected,
        };
      }
    } else {
      if (editingId) commitEdit();
      select(null);
      gesture.current = { kind: 'pan', sx: e.clientX, sy: e.clientY, ox: pan.x, oy: pan.y };
    }
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
  };

  useEffect(() => {
    return () => {
      if (rafId.current) cancelAnimationFrame(rafId.current);
    };
  }, []);

  /** Takes the one undo snapshot for this gesture, the first time (and only
   *  the first time) a gesture actually writes a change. */
  const ensureHistory = useCallback(() => {
    if (!historySaved.current) {
      historySaved.current = true;
      snapshot();
    }
  }, [snapshot]);

  const performMove = useCallback((clientX: number, clientY: number) => {
    const g = gesture.current;
    if (g.kind === 'none') return;

    if (g.kind === 'pan') {
      setPan(clampPan({ x: g.ox + (clientX - g.sx), y: g.oy + (clientY - g.sy) }, zoom));
      return;
    }

    if (g.kind === 'move') {
      const el = project.elements.find((x) => x.id === g.id);
      if (!el) return;
      const rawX = g.ox + (clientX - g.sx) / scale;
      const rawY = g.oy + (clientY - g.sy) / scale;

      const snapped = computeMoveSnap({ x: rawX, y: rawY, width: el.width, height: el.height }, g.candidates, SNAP);
      setGuides((prev) => (prev.x === snapped.guideX && prev.y === snapped.guideY ? prev : { x: snapped.guideX, y: snapped.guideY }));

      const nx = Math.round(snapped.x), ny = Math.round(snapped.y);
      const patch: Transient = { [g.id]: { x: nx, y: ny } };
      if (g.siblings.length) {
        const dx = snapped.x - g.ox, dy = snapped.y - g.oy;
        for (const sib of g.siblings) {
          patch[sib.id] = { x: Math.round(sib.ox + dx), y: Math.round(sib.oy + dy) };
        }
      }
      ensureHistory();
      applyTransient(patch);
      return;
    }

    if (g.kind === 'resize') {
      const dx = (clientX - g.sx) / scale;
      const dy = (clientY - g.sy) / scale;
      const el = project.elements.find((q) => q.id === g.id);
      const isRatioLocked = el?.lockAspectRatio || (g.handle.length === 2 && (el?.type === 'image' || el?.type === 'decor'));

      const target = computeResizeTarget({
        handle: g.handle,
        base: { x: g.b.x, y: g.b.y, width: g.b.w, height: g.b.h },
        dx, dy,
        lockAspect: !!isRatioLocked,
        ratio: g.ratio,
      });

      if (el?.type === 'text') {
        const fit = measureTextBox({ ...(el as TextElement) }, { maxWidth: Math.round(target.width) });
        target.height = fit.height;
      }

      ensureHistory();
      applyTransient({
        [g.id]: { x: Math.round(target.x), y: Math.round(target.y), width: Math.round(target.width), height: Math.round(target.height) },
      });
      return;
    }

    if (g.kind === 'rotate') {
      const deg = computeRotateTarget({
        centerClientX: g.cx, centerClientY: g.cy,
        startAngleClient: g.start, startRotation: g.from,
        nowClientX: clientX, nowClientY: clientY,
      });
      ensureHistory();
      applyTransient({ [g.id]: { rotation: deg } });
    }
  }, [project, scale, zoom, clampPan, ensureHistory, applyTransient]);

  const onPointerMove = (e: React.PointerEvent) => {
    if (pointers.current.has(e.pointerId)) pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const g = gesture.current;
    if (g.kind === 'none') return;
    moved.current = true;

    if (g.kind === 'pinch') {
      if (pointers.current.size < 2) return;
      const [a, b] = [...pointers.current.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      const result = computePinchZoomPan(
        {
          startDistance: g.d0, startZoom: g.z0, startPan: { x: g.ox, y: g.oy },
          startMidpoint: { x: g.mx, y: g.my },
          wrapCenter: { x: g.wrapCenterX, y: g.wrapCenterY },
          minZoom: MIN_Z, maxZoom: MAX_Z,
        },
        d,
        { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }
      );
      setZoom(result.zoom);
      setPan(clampPan(result.pan, result.zoom));
      return;
    }

    // Schedule RAF update for silky smooth movement without frame drops on low RAM phones
    pendingMove.current = { clientX: e.clientX, clientY: e.clientY };
    if (!rafId.current) {
      rafId.current = requestAnimationFrame(() => {
        rafId.current = null;
        if (pendingMove.current) {
          performMove(pendingMove.current.clientX, pendingMove.current.clientY);
        }
      });
    }
  };

  const onPointerUp = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    if (rafId.current) {
      cancelAnimationFrame(rafId.current);
      rafId.current = null;
    }
    if (pendingMove.current) {
      performMove(pendingMove.current.clientX, pendingMove.current.clientY);
      pendingMove.current = null;
    }
    const g = gesture.current;

    // Commit the gesture's final transform to the store exactly once. Until
    // now everything lived in local `transient` state (see the note above
    // the Transient type) so the drag never touched Zustand or re-rendered
    // element content on every frame. Read transientRef (not the `transient`
    // state variable) here — performMove's last call this same tick may have
    // just called applyTransient, and setState from that hasn't flushed into
    // this closure's `transient` yet, but the ref is already up to date.
    const finalPatch = transientRef.current;
    if (finalPatch && (g.kind === 'move' || g.kind === 'resize' || g.kind === 'rotate')) {
      updateMany(Object.entries(finalPatch).map(([id, patch]) => ({ id, patch })));
    }
    applyTransient(null);

    // Tap a text layer that was *already* selected (not this same tap's
    // initial select) to start editing it in place — this is the "tap
    // again to edit" flow the README describes. A plain first tap only
    // selects, same as tapping any other element.
    if (!moved.current && g.kind === 'move' && g.wasAlreadySelected) {
      const el = project.elements.find((x) => x.id === g.id);
      if (el?.type === 'text') startEdit(g.id);
    }

    if (pointers.current.size === 0) gesture.current = { kind: 'none' };
    setGuides({});
  };

  const editingEl = editingId ? (project.elements.find((e) => e.id === editingId) as TextElement | undefined) : null;

  return (
    <div
      ref={wrapRef}
      className="relative w-full h-full overflow-hidden touch-none select-none bg-canvasbg"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
    >
      <div
        className="absolute left-1/2 top-1/2"
        style={{ transform: `translate(-50%,-50%) translate(${pan.x}px, ${pan.y}px)` }}
      >
        <div
          ref={stageRef}
          className="relative bg-white"
          style={{
            width: project.canvas.width * scale,
            height: project.canvas.height * scale,
            boxShadow: '0 8px 40px rgba(18,19,26,.14)',
            borderRadius: 2,
          }}
        >
          <div
            style={{
              width: project.canvas.width,
              height: project.canvas.height,
              transform: `scale(${scale})`,
              transformOrigin: 'top left',
              position: 'absolute',
              overflow: 'hidden',
            }}
          >
            <BackgroundView bg={project.background} />

            {els.map((el) => {
              if (el.hidden) return null;
              const isEditing = editingId === el.id;
              // Live, uncommitted position/size/rotation for this element if
              // it's the one mid-gesture — everything else renders straight
              // from committed store state and never re-renders during a
              // neighbour's drag (el's own object identity below is passed
              // to ElementView unchanged, so React.memo skips it too).
              const patch = transient?.[el.id];
              const dx = patch?.x ?? el.x;
              const dy = patch?.y ?? el.y;
              const dw = patch?.width ?? el.width;
              const dh = patch?.height ?? el.height;
              const drot = patch?.rotation ?? el.rotation;
              // Thin/small elements (a divider line, a small icon) get an
              // invisible hit-slop so they're easy to grab by touch instead
              // of needing a pixel-perfect tap inside a tiny box.
              const MIN_TOUCH = 34;
              const slopX = Math.max(0, (MIN_TOUCH / scale - dw) / 2);
              const slopY = Math.max(0, (MIN_TOUCH / scale - dh) / 2);
              return (
                <div
                  key={el.id}
                  id={`el-${el.id}`}
                  data-el={el.id}
                  style={{
                    position: 'absolute', left: dx, top: dy, width: dw, height: dh,
                    transform: `rotate(${drot}deg)`, opacity: el.opacity, zIndex: el.z,
                    visibility: isEditing ? 'hidden' : 'visible',
                    pointerEvents: 'auto',
                    cursor: 'move',
                  }}
                >
                  {(slopX > 0 || slopY > 0) && (
                    <div
                      data-el={el.id}
                      style={{
                        position: 'absolute',
                        top: -slopY, bottom: -slopY, left: -slopX, right: -slopX,
                        pointerEvents: 'auto',
                      }}
                    />
                  )}
                  <ElementView el={el} />
                </div>
              );
            })}

            {/* Solid, forward-typing inline textarea that eliminates the backwards text bug */}
            {editingEl && editingEl.type === 'text' && (
              <div
                style={{
                  position: 'absolute',
                  left: editingEl.x,
                  top: editingEl.y,
                  width: editingEl.width,
                  minHeight: editingEl.height,
                  height: 'auto',
                  transform: `rotate(${editingEl.rotation}deg)`,
                  zIndex: 9998,
                  pointerEvents: 'auto',
                  display: 'flex',
                  alignItems: editingEl.vAlign === 'middle' ? 'center' : editingEl.vAlign === 'bottom' ? 'flex-end' : 'flex-start',
                  justifyContent: editingEl.align === 'center' ? 'center' : editingEl.align === 'right' ? 'flex-end' : 'flex-start',
                }}
              >
                <div className="relative w-full h-full">
                  <textarea
                    ref={textareaRef}
                    value={editText}
                    onChange={(e) => {
                      setEditText(e.target.value);
                      const fit = measureTextBox({ ...editingEl, text: e.target.value }, { maxWidth: editingEl.width });
                      update(editingEl.id, { text: e.target.value, height: fit.height, autoFit: false } as any);
                    }}
                    onBlur={commitEdit}
                    onKeyDown={(e) => {
                      if (e.key === 'Escape') commitEdit();
                      // Enter inserts a new line, like Canva — the checkmark
                      // below (or tapping away) is what finishes editing.
                      e.stopPropagation();
                    }}
                    autoFocus
                    spellCheck={false}
                    style={{
                      width: '100%',
                      minHeight: editingEl.height,
                      overflow: 'hidden',
                      resize: 'none',
                      background: editingEl.highlight ? editingEl.highlight.color : 'rgba(255,255,255,0.85)',
                      border: '2px solid #F02D63',
                      borderRadius: 6,
                      fontFamily: `"${editingEl.fontFamily}", sans-serif`,
                      fontSize: `${editingEl.fontSize}px`,
                      fontWeight: editingEl.fontWeight,
                      fontStyle: editingEl.italic ? 'italic' : 'normal',
                      textAlign: editingEl.align,
                      color: editingEl.color,
                      lineHeight: editingEl.lineHeight,
                      letterSpacing: `${editingEl.letterSpacing}px`,
                      textTransform: editingEl.uppercase ? 'uppercase' : 'none',
                      textDecorationLine: editingEl.underline && editingEl.strikethrough ? 'underline line-through' : editingEl.underline ? 'underline' : editingEl.strikethrough ? 'line-through' : 'none',
                      padding: editingEl.highlight ? `${editingEl.highlight.padY}px ${editingEl.highlight.padX}px` : '0px',
                      margin: 0,
                      outline: 'none',
                      caretColor: '#F02D63',
                      boxShadow: '0 4px 20px rgba(240,45,99,0.25)',
                    }}
                  />
                </div>
              </div>
            )}

            {guides.x !== undefined && (
              <div style={{ position: 'absolute', left: guides.x, top: 0, bottom: 0, width: 2 / scale, background: '#F02D63', zIndex: 9999 }} />
            )}
            {guides.y !== undefined && (
              <div style={{ position: 'absolute', top: guides.y, left: 0, right: 0, height: 2 / scale, background: '#F02D63', zIndex: 9999 }} />
            )}
          </div>

          {/* Selection chrome with 8 handles and persistent border */}
          {selected && displaySelected && !editingId && (
            <Selection
              el={displaySelected}
              scale={scale}
              onStartEdit={() => startEdit(selected.id)}
              onCrop={() => onCropImage?.(selected.id)}
              onQuick={{ del, duplicate, reorder, replace: onRequestImage }}
            />
          )}
        </div>
      </div>

      {zoom !== 1 && (
        <div
          className="absolute left-3 bottom-3 rounded-full bg-ink/80 text-white text-[11px] font-semibold px-2.5 py-1 backdrop-blur-sm"
          style={{ pointerEvents: 'none' }}
        >
          {Math.round(zoom * 100)}%
        </div>
      )}
    </div>
  );
}

function Selection({
  el,
  scale,
  onStartEdit,
  onCrop,
  onQuick,
}: {
  el: DesignElement;
  scale: number;
  onStartEdit: () => void;
  onCrop: () => void;
  onQuick: {
    del: (id: string) => void;
    duplicate: (id: string) => void;
    reorder: (id: string, d: 'front' | 'back' | 'up' | 'down') => void;
    replace: (id: string) => void;
  };
}) {
  const box = { left: el.x * scale, top: el.y * scale, width: el.width * scale, height: el.height * scale };
  // Full 8-handle set for rich Photoshop/Canva style resizing
  const handles = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'] as const;

  return (
    <div
      data-selection-id={el.id}
      className="absolute"
      style={{ ...box, transform: `rotate(${el.rotation}deg)`, zIndex: 10000, pointerEvents: 'none' }}
    >
      {/* Selection outline border with data-el so clicking border maintains selection and allows dragging */}
      <div
        data-el={el.id}
        className="absolute inset-0 border-2 border-brand rounded-[3px]"
        style={{ pointerEvents: 'auto', cursor: 'move' }}
      />

      {/* 8 Resizing handles - substantially smaller and clearly distinguished */}
      {handles.map((h) => {
        const isCorner = h.length === 2;
        const isEW = h === 'w' || h === 'e';
        const isNS = h === 'n' || h === 's';

        const style: React.CSSProperties = { position: 'absolute', pointerEvents: 'auto', touchAction: 'none' };
        if (isCorner) {
          if (h.includes('n')) style.top = -5;
          else if (h.includes('s')) style.bottom = -5;
          if (h.includes('w')) style.left = -5;
          else if (h.includes('e')) style.right = -5;
        } else if (isNS) {
          if (h === 'n') style.top = -2.5;
          else style.bottom = -2.5;
          style.left = '50%';
          style.marginLeft = -7;
        } else if (isEW) {
          if (h === 'w') style.left = -2.5;
          else style.right = -2.5;
          style.top = '50%';
          style.marginTop = -7;
        }

        return (
          <div
            key={h}
            data-handle={h}
            className="before:content-[''] before:absolute before:-inset-2.5 before:z-10"
            style={{
              ...style,
              width: isCorner ? 10 : isEW ? 5 : 14,
              height: isCorner ? 10 : isEW ? 14 : 5,
              borderRadius: 999,
              background: '#fff',
              border: '1.5px solid #F02D63',
              boxShadow: '0 1px 3px rgba(18,19,26,.3)',
              cursor: isCorner ? `${h}-resize` : isEW ? 'ew-resize' : 'ns-resize',
            }}
          />
        );
      })}

      {/* Rotate Knob */}
      <div
        data-handle="rotate"
        className="before:content-[''] before:absolute before:-inset-2 before:z-10"
        style={{
          position: 'absolute', bottom: -36, left: '50%', marginLeft: -16,
          width: 22, height: 22, borderRadius: 999, background: '#fff',
          border: '1.5px solid #F02D63', pointerEvents: 'auto', touchAction: 'none',
          display: 'grid', placeItems: 'center', boxShadow: '0 1px 4px rgba(18,19,26,.25)',
          cursor: 'grab',
        }}
      >
        <RotateCw size={12} color="#F02D63" strokeWidth={2.2} />
      </div>

      {/* Move Knob (Crosshair) */}
      <div
        data-handle="move"
        className="before:content-[''] before:absolute before:-inset-2 before:z-10"
        style={{
          position: 'absolute', bottom: -36, left: '50%', marginLeft: 16,
          width: 22, height: 22, borderRadius: 999, background: '#fff',
          border: '1.5px solid #F02D63', pointerEvents: 'auto', touchAction: 'none',
          display: 'grid', placeItems: 'center', boxShadow: '0 1px 4px rgba(18,19,26,.25)',
          cursor: 'move',
        }}
      >
        <Move size={12} color="#F02D63" strokeWidth={2.2} />
      </div>

      {/* Floating Quick Action Bar */}
      <div
        style={{
          position: 'absolute',
          top: -54,
          left: '50%',
          transform: `translateX(-50%) rotate(${-el.rotation}deg)`,
          pointerEvents: 'auto',
        }}
        className="flex items-center gap-1 rounded-full bg-ink text-white px-2 py-1 shadow-xl border border-white/10 backdrop-blur-md"
      >
        {el.type === 'text' && (
          <button
            onPointerDown={(e) => e.stopPropagation()}
            onClick={onStartEdit}
            className="px-2.5 py-1 rounded-full bg-brand text-white text-[12px] font-bold flex items-center gap-1 active:bg-brand-dark"
          >
            <Edit3 size={13} />
            <span>Edit</span>
          </button>
        )}

        {el.type === 'image' && (
          <>
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onClick={onCrop}
              className="px-2.5 py-1 rounded-full bg-brand text-white text-[12px] font-bold flex items-center gap-1 active:bg-brand-dark"
            >
              <Crop size={13} />
              <span>Crop</span>
            </button>
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onClick={() => onQuick.replace(el.id)}
              className="p-1.5 rounded-full active:bg-white/15 text-white/90"
              title="Replace image"
            >
              <IcSwap size={16} />
            </button>
          </>
        )}

        <button
          onPointerDown={(e) => e.stopPropagation()}
          onClick={() => onQuick.duplicate(el.id)}
          className="p-1.5 rounded-full active:bg-white/15 text-white/90"
          title="Duplicate"
        >
          <IcCopy size={16} />
        </button>

        <button
          onPointerDown={(e) => e.stopPropagation()}
          onClick={() => onQuick.del(el.id)}
          className="p-1.5 rounded-full active:bg-white/15 text-[#FF8E9E]"
          title="Delete"
        >
          <IcTrash size={16} />
        </button>

        <button
          onPointerDown={(e) => e.stopPropagation()}
          onClick={() => {
            // Trigger more menu
            const ev = new CustomEvent('open-more-menu', { detail: { id: el.id } });
            window.dispatchEvent(ev);
          }}
          className="p-1.5 rounded-full active:bg-white/15 text-white/90"
          title="More options"
        >
          <MoreHorizontal size={18} />
        </button>
      </div>
    </div>
  );
}
