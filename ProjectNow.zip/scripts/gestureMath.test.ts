// Plain assert-based tests for src/editor/gestureMath.ts — no browser, no
// test framework. Run with: npx tsx scripts/gestureMath.test.ts
import {
  snapAngle,
  computeRotateTarget,
  buildSnapCandidates,
  computeMoveSnap,
  computeResizeTarget,
  computePinchZoomPan,
} from '../src/editor/gestureMath';

let passed = 0;
let failed = 0;

function approx(a: number, b: number, eps = 0.5) {
  return Math.abs(a - b) <= eps;
}

function check(name: string, cond: boolean) {
  if (cond) {
    passed++;
  } else {
    failed++;
    console.error(`FAIL: ${name}`);
  }
}

// ---- snapAngle ----
check('snapAngle snaps 43deg to 45', snapAngle(43) === 45);
check('snapAngle snaps 92deg to 90', snapAngle(92) === 90);
check('snapAngle leaves 30deg alone (>4deg from 15/45)', snapAngle(30) === 30);
check('snapAngle snaps -2deg to 0', snapAngle(-2) === 0);
check('snapAngle snaps 179deg to 180', snapAngle(179) === 180);

// ---- computeRotateTarget ----
{
  // Element centered at (100,100). Start drag at 3 o'clock (0deg from center).
  const startAngleClient = 0; // atan2(0, 1) in degrees
  // Drag to 12 o'clock-ish, ~91deg away from start -> should land near 90 and snap.
  const rotated = computeRotateTarget({
    centerClientX: 100,
    centerClientY: 100,
    startAngleClient,
    startRotation: 0,
    nowClientX: 100 + Math.cos((91 * Math.PI) / 180) * 50,
    nowClientY: 100 + Math.sin((91 * Math.PI) / 180) * 50,
  });
  check(`computeRotateTarget snaps near-90deg drag to 90 (got ${rotated})`, rotated === 90);
}

// ---- computeMoveSnap ----
{
  const candidates = buildSnapCandidates(1080, 1080, [{ x: 500, y: 500, width: 200, height: 100 }]);
  // Box nearly centered horizontally (cx should snap to 540)
  const nearCenter = computeMoveSnap({ x: 480 - 5, y: 10, width: 120, height: 40 }, candidates);
  check(
    `computeMoveSnap snaps to canvas horizontal center (guideX=${nearCenter.guideX})`,
    nearCenter.guideX === 540
  );

  // Box left edge close to the other element's right edge (700) -> should snap
  const nearSibling = computeMoveSnap({ x: 705, y: 10, width: 80, height: 40 }, candidates);
  check(
    `computeMoveSnap snaps to a sibling's right edge (x=${nearSibling.x}, guideX=${nearSibling.guideX})`,
    nearSibling.x === 700 && nearSibling.guideX === 700
  );

  // Box far from anything -> no snap, values pass through unchanged
  const farAway = computeMoveSnap({ x: 123, y: 456, width: 30, height: 30 }, candidates);
  check('computeMoveSnap leaves an unsnapped box alone', farAway.x === 123 && farAway.y === 456);
}

// ---- computeResizeTarget ----
{
  // Free resize from the SE corner: width/height grow with dx/dy, x/y unchanged.
  const free = computeResizeTarget({
    handle: 'se',
    base: { x: 10, y: 10, width: 100, height: 50 },
    dx: 20,
    dy: 5,
  });
  check(`free SE resize grows w/h (got ${JSON.stringify(free)})`, free.width === 120 && free.height === 55 && free.x === 10 && free.y === 10);

  // NW corner resize moves x/y as it shrinks/grows
  const nw = computeResizeTarget({
    handle: 'nw',
    base: { x: 10, y: 10, width: 100, height: 50 },
    dx: -10,
    dy: -10,
  });
  check(`NW resize shifts x/y (got ${JSON.stringify(nw)})`, nw.x === 0 && nw.y === 0 && nw.width === 110 && nw.height === 60);

  // Aspect-locked resize from an edge handle keeps the ratio
  const locked = computeResizeTarget({
    handle: 'e',
    base: { x: 0, y: 0, width: 100, height: 50 },
    dx: 50,
    dy: 0,
    lockAspect: true,
    ratio: 2,
  });
  check(`aspect-locked E resize keeps ratio 2 (got ${JSON.stringify(locked)})`, locked.width === 150 && locked.height === 75);

  // Never shrinks below minSize
  const clamped = computeResizeTarget({
    handle: 'e',
    base: { x: 0, y: 0, width: 20, height: 20 },
    dx: -500,
    dy: 0,
  });
  check(`resize respects minSize floor (got width=${clamped.width})`, clamped.width === 16);
}

// ---- computePinchZoomPan ----
{
  const input = {
    startDistance: 100,
    startZoom: 1,
    startPan: { x: 5, y: -10 },
    startMidpoint: { x: 300, y: 400 },
    wrapCenter: { x: 250, y: 350 },
    minZoom: 0.4,
    maxZoom: 4,
  };
  // Double the finger spacing (zoom should double), fingers don't drift.
  const result = computePinchZoomPan(input, 200, { x: 300, y: 400 });
  check(`pinch zoom doubles (got ${result.zoom})`, approx(result.zoom, 2, 0.01));

  // The critical property: the canvas-space point that was under the
  // fingers at the start must still project to the (unmoved) midpoint
  // after zoom changes. Re-derive the projected screen point with the
  // *new* zoom/pan and check it lands back on startMidpoint.
  const stageOffsetX = (input.startMidpoint.x - input.wrapCenter.x - input.startPan.x) / input.startZoom;
  const stageOffsetY = (input.startMidpoint.y - input.wrapCenter.y - input.startPan.y) / input.startZoom;
  const projectedX = input.wrapCenter.x + result.pan.x + stageOffsetX * result.zoom;
  const projectedY = input.wrapCenter.y + result.pan.y + stageOffsetY * result.zoom;
  check(
    `pinch zoom keeps the focal point under the fingers (got ${projectedX.toFixed(2)},${projectedY.toFixed(2)})`,
    approx(projectedX, 300) && approx(projectedY, 400)
  );

  // Same check again but with the fingers also drifting sideways during
  // the pinch (currentMidpoint != startMidpoint) — the focal point should
  // now track the new midpoint instead.
  const drifted = computePinchZoomPan(input, 150, { x: 340, y: 380 });
  const dz = drifted.zoom;
  const projectedX2 = input.wrapCenter.x + drifted.pan.x + stageOffsetX * dz;
  const projectedY2 = input.wrapCenter.y + drifted.pan.y + stageOffsetY * dz;
  check(
    `pinch zoom tracks a drifting midpoint (got ${projectedX2.toFixed(2)},${projectedY2.toFixed(2)})`,
    approx(projectedX2, 340) && approx(projectedY2, 380)
  );

  // Zoom clamps to maxZoom
  const overZoom = computePinchZoomPan(input, 1000, { x: 300, y: 400 });
  check(`pinch zoom clamps to maxZoom (got ${overZoom.zoom})`, overZoom.zoom === 4);
}

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
